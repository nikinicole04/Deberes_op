import javax.swing.*;

public class Principal {
    public static void main(String[] args) {
        Pila data = new Pila();

        try {
            data.push("Elemento 1");
            data.push("Elemento 2");
            data.push("Elemento 3");
            data.push("Elemento 4");
            data.push("Elemento 5");

            System.out.println("Pila:");
            System.out.println(data.toString());

            String eliminado = data.pop();
            JOptionPane.showMessageDialog(null, "Elemento eliminado: " + eliminado);

            System.out.println("Pila después de eliminar:");
            System.out.println(data.toString());

            JOptionPane.showMessageDialog(null,
                    "En la cima de la pila está: " + data.cima());

            Pila pilaConLimite = new Pila();
            for (int i = 1; i <= 11; i++) {
                try {
                    pilaConLimite.push("Elemento " + i);
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, e.getMessage());
                }
            }

            JOptionPane.showMessageDialog(null, "Pila con límite:\n" + pilaConLimite.toString());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }
}
