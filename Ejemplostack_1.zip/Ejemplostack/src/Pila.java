import java.util.Stack;

public class Pila {
    private Stack<String> coleccion;
    private static final int LIMITE = 10;

    public Pila() {
        coleccion = new Stack<>();
    }

    public void push(String dato) throws Exception {
        if (coleccion.size() >= LIMITE) {
            throw new Exception("Error: no se puede agregar más de " + LIMITE + " elementos a la pila.");
        }
        coleccion.push(dato);
    }

    public String pop() throws Exception {
        if (coleccion.isEmpty()) {
            throw new Exception("Error en método pop, pila vacía.");
        }
        return coleccion.pop();
    }

    public String cima() throws Exception {
        if (coleccion.isEmpty()) {
            throw new Exception("Error: la pila está vacía.");
        }
        return coleccion.peek();
    }

    public int tamanio() {
        return coleccion.size();
    }

    @Override
    public String toString() {
        StringBuilder listado = new StringBuilder();
        for (int i = coleccion.size() - 1; i >= 0; i--) {
            listado.append(coleccion.get(i)).append("\n");
        }
        return listado.toString();
    }
}
