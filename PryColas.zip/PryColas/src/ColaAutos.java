import java.util.LinkedList;
import java.util.Queue;

public class ColaAutos {
    private Queue<Auto> listaautos;

    public ColaAutos() {
        listaautos = new LinkedList<Auto>();
    }

    public void encolar(Auto dato) {
        listaautos.add(dato);
    }

    public Auto desencolar() throws Exception {
        if (listaautos.isEmpty())
            throw new Exception("Ya no existen autos encolados");
        return listaautos.peek(); //Muestra el incio pero no lo elimina
    }

    public String listarTodos() {
        StringBuilder sb = new StringBuilder();
        for (Auto a1 : listaautos) {
            sb.append(a1.toString());
        }
        return sb.toString();
    }

}
